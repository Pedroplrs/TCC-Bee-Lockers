<?php

//declarar variáveis de conexão - banco de dados
$hostname = "localhost";
$username = "root";
$password = "";
$database = "bee_lockers";

//flag para exibir debug de conexão, mensagem de ok
$flag_exibir = false;